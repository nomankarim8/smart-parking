import type { Slot } from '../types';

const styles: Record<string, string> = {
  AVAILABLE: 'border-emerald-400/30 bg-emerald-400/5 text-emerald-300',
  OCCUPIED: 'border-rose-400/30 bg-rose-400/5 text-rose-300',
  RESERVED: 'border-amber-400/30 bg-amber-400/5 text-amber-300',
  MAINTENANCE: 'border-slate-600 bg-slate-800/50 text-slate-400',
};

export default function SlotGrid({ slots }: { slots: Slot[] }) {
  return (
    <div className="grid-bg rounded-2xl border border-slate-800 p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-white">Live Parking Map</h3>
          <p className="text-xs text-slate-500">Real-time slot occupancy</p>
        </div>
        <div className="flex gap-3 text-[11px] text-slate-500">
          <span>🟢 Available</span>
          <span>🔴 Occupied</span>
          <span>🟡 Reserved</span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        {slots.map((s) => (
          <div key={s.slot_id} className={`rounded-2xl border-2 p-4 ${styles[s.status]}`}>
            <div className="flex items-center justify-between">
              <span className="text-lg font-black">{s.slot_number}</span>
              <span className="h-2.5 w-2.5 rounded-full bg-current" />
            </div>
            <div className="mt-7 text-[10px] font-bold uppercase tracking-widest opacity-80">{s.status}</div>
            <div className="mt-1 text-[10px] opacity-50">{s.category}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

