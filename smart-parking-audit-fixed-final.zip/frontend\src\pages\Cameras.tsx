import { useEffect, useMemo, useState } from 'react';
import { CircleDot, Edit3, MapPin, Plus, Save, Trash2, UploadCloud, Video, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../services/api';
 
type CameraRole = 'ENTRY' | 'EXIT' | 'PARKING_ZONE';
type CameraType = 'USB' | 'IP' | 'RTSP' | 'UPLOAD' | 'DEMO';
type CameraStatus = 'ONLINE' | 'OFFLINE' | 'UNKNOWN';

type CameraItem = {
  camera_id: number;
  camera_name: string;
  location: string;
  camera_role: CameraRole;
  camera_type: CameraType;
  stream_configured: boolean;
  status: CameraStatus;
};

type FormState = {
  camera_name: string;
  location: string;
  camera_role: CameraRole;
  camera_type: CameraType;
  stream_url: string;
};

const emptyForm: FormState = {
  camera_name: '',
  location: '',
  camera_role: 'PARKING_ZONE',
  camera_type: 'DEMO',
  stream_url: '',
};

const roleMeta: Record<CameraRole, { label: string; icon: string; description: string }> = {
  ENTRY: { label: 'Entry Gate', icon: 'IN', description: 'Vehicle entry + ALPR capture' },
  EXIT: { label: 'Exit Gate', icon: 'OUT', description: 'Exit ALPR + checkout capture' },
  PARKING_ZONE: { label: 'Parking Zone', icon: 'PZ', description: 'Parking-area monitoring' },
};

function errorMessage(error: unknown) {
  if (typeof error === 'object' && error !== null && 'response' in error) {
    const response = error.response;
    if (typeof response === 'object' && response !== null && 'data' in response) {
      const data = response.data;
      if (typeof data === 'object' && data !== null && 'detail' in data && typeof data.detail === 'string') {
        return data.detail;
      }
    }
  }
  return 'Camera operation failed. Please try again.';
}

export default function Cameras() {
  const [cameras, setCameras] = useState<CameraItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [editing, setEditing] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [videoCameraId, setVideoCameraId] = useState('');
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploadingVideo, setUploadingVideo] = useState(false);

  const fetchCameras = async () => {
    try {
      const res = await api.get<CameraItem[]>('/cameras/');
      setCameras(res.data);
      setVideoCameraId((current) => current || String(res.data[0]?.camera_id ?? ''));
    } catch {
      setMessage('Unable to load camera configuration.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void fetchCameras(); }, []);

  const summary = useMemo(() => ({
    total: cameras.length,
    online: cameras.filter(c => c.status === 'ONLINE').length,
    entry: cameras.filter(c => c.camera_role === 'ENTRY').length,
    exit: cameras.filter(c => c.camera_role === 'EXIT').length,
    zone: cameras.filter(c => c.camera_role === 'PARKING_ZONE').length,
  }), [cameras]);

  const updateField = <K extends keyof FormState>(key: K, value: FormState[K]) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const startEdit = (camera: CameraItem) => {
    setEditing(camera.camera_id);
    setForm({
      camera_name: camera.camera_name,
      location: camera.location,
      camera_role: camera.camera_role,
      camera_type: camera.camera_type,
      stream_url: '',
    });
    setMessage('');
  };

  const resetForm = () => {
    setEditing(null);
    setForm(emptyForm);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.camera_name.trim() || !form.location.trim()) {
      setMessage('Camera name and location are required.');
      return;
    }
    setSaving(true);
    setMessage('');
    try {
      const { stream_url, ...cameraFields } = form;
      const payload = stream_url.trim()
        ? { ...cameraFields, stream_url: stream_url.trim() }
        : editing ? cameraFields : { ...cameraFields, stream_url: '' };
      if (editing) {
        await api.put(`/cameras/${editing}`, payload);
        setMessage('Camera configuration updated successfully.');
      } else {
        await api.post('/cameras/', payload);
        setMessage('Camera added successfully.');
      }
      resetForm();
      await fetchCameras();
    } catch (error: unknown) {
      setMessage(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const remove = async (camera: CameraItem) => {
    if (!window.confirm(`Delete ${camera.camera_name}?`)) return;
    try {
      await api.delete(`/cameras/${camera.camera_id}`);
      setMessage('Camera deleted successfully.');
      if (editing === camera.camera_id) resetForm();
      await fetchCameras();
    } catch (error: unknown) {
      setMessage(errorMessage(error));
    }
  };

  const uploadDemoVideo = async () => {
    if (!videoCameraId || !videoFile) {
      setMessage('Choose a camera and a video file first.');
      return;
    }
    setUploadingVideo(true);
    setMessage('');
    try {
      const body = new FormData();
      body.append('file', videoFile);
      const response = await api.post<CameraItem>(`/cameras/${videoCameraId}/upload-video`, body);
      setCameras(current => current.map(camera => camera.camera_id === response.data.camera_id ? response.data : camera));
      setVideoFile(null);
      setMessage(`${response.data.camera_name} demo video is ready. Open CCTV Monitor to review live playback and run ALPR.`);
    } catch (error: unknown) {
      setMessage(errorMessage(error));
    } finally {
      setUploadingVideo(false);
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-[.24em] text-indigo-300">Infrastructure / Cameras</div>
          <h1 className="mt-2 text-3xl font-black text-white sm:text-4xl">Camera Management</h1>
          <p className="mt-2 max-w-3xl text-slate-400">Configure dedicated Entry, Exit and Parking Zone cameras for the ALPR workflow.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/monitor" className="inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm font-bold text-emerald-200 hover:bg-emerald-400/15"><Video size={18}/> CCTV Monitor</Link>
          <button onClick={resetForm} className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white hover:bg-white/10">
            <Plus size={18}/> Add Camera
          </button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {[
          ['Total Cameras', summary.total, 'text-white'],
          ['Online', summary.online, 'text-emerald-300'],
          ['Entry', summary.entry, 'text-sky-300'],
          ['Exit', summary.exit, 'text-amber-300'],
          ['Parking Zone', summary.zone, 'text-violet-300'],
        ].map(([label, value, tone]) => (
          <div key={String(label)} className="glass rounded-2xl p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">{label}</div>
            <div className={`mt-2 text-3xl font-black ${tone}`}>{value}</div>
          </div>
        ))}
      </div>

      <section className="glass mt-6 rounded-2xl p-5 sm:p-6">
        <div className="mb-4 flex items-start gap-3">
          <div className="rounded-xl bg-indigo-500/10 p-2 text-indigo-300"><UploadCloud size={20}/></div>
          <div><h2 className="font-bold text-white">Video input · camera demo mode</h2><p className="mt-1 text-sm text-slate-500">Upload an MP4/AVI/MOV/MKV/WebM clip (max 100 MB) to simulate a camera feed and test plate recognition.</p></div>
        </div>
        {cameras.length===0?<p className="text-sm text-amber-300">Add a camera before uploading a demo clip.</p>:<div className="grid gap-3 md:grid-cols-[1fr_1.4fr_auto] md:items-end">
          <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Camera</span><select value={videoCameraId} onChange={event=>setVideoCameraId(event.target.value)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white">{cameras.map(camera=><option key={camera.camera_id} value={camera.camera_id}>{camera.camera_name} · {camera.camera_role}</option>)}</select></label>
          <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Video clip</span><input type="file" accept="video/mp4,video/quicktime,video/x-msvideo,video/x-matroska,video/webm,.mp4,.mov,.avi,.mkv,.webm" onChange={event=>setVideoFile(event.target.files?.[0]||null)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-3 py-2.5 text-sm text-slate-300 file:mr-3 file:rounded-lg file:border-0 file:bg-indigo-500/15 file:px-3 file:py-2 file:text-xs file:font-bold file:text-indigo-200"/></label>
          <button type="button" disabled={uploadingVideo||!videoFile} onClick={()=>void uploadDemoVideo()} className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-500 px-4 py-3 text-sm font-bold text-white disabled:opacity-50"><UploadCloud size={17}/>{uploadingVideo?'UPLOADING…':'UPLOAD VIDEO'}</button>
        </div>}
      </section>

      <div className="mt-8 grid gap-6 xl:grid-cols-[1.15fr_1fr]">
        <div className="glass rounded-2xl p-6">
          <div className="mb-5 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-black text-white">Registered Cameras</h2>
              <p className="mt-1 text-sm text-slate-500">These cameras are available to the parking workflow.</p>
            </div>
            <div className="rounded-xl border border-indigo-400/20 bg-indigo-400/10 px-3 py-2 text-xs font-bold text-indigo-200">ALPR READY</div>
          </div>

          {message && <div className="mb-4 rounded-xl border border-indigo-400/20 bg-indigo-400/10 px-4 py-3 text-sm text-indigo-100">{message}</div>}

          <div className="space-y-3">
            {loading ? <div className="rounded-xl border border-white/5 bg-white/[0.03] p-8 text-center text-slate-500">Loading cameras…</div> : cameras.length === 0 ? <div className="rounded-xl border border-dashed border-white/10 p-10 text-center text-slate-500">No cameras configured yet.</div> : cameras.map(camera => {
              const meta = roleMeta[camera.camera_role];
              return (
                <div key={camera.camera_id} className="rounded-2xl border border-white/5 bg-white/[0.025] p-4 transition hover:bg-white/[0.04]">
                  <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="flex items-start gap-3">
                      <div className="grid size-11 place-items-center rounded-xl bg-indigo-500/10 text-xs font-black text-indigo-200">{meta.icon}</div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-black text-white">{camera.camera_name}</h3>
                          <span className={`rounded-full px-2 py-1 text-[10px] font-black ${camera.status === 'ONLINE' ? 'bg-emerald-400/10 text-emerald-300' : camera.status === 'OFFLINE' ? 'bg-rose-400/10 text-rose-300' : 'bg-white/10 text-slate-400'}`}>{camera.status}</span>
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-slate-500">
                          <span className="inline-flex items-center gap-1"><MapPin size={13}/>{camera.location}</span>
                          <span className="inline-flex items-center gap-1"><Video size={13}/>{camera.camera_type}</span>
                          <span>{camera.stream_configured ? 'Source configured' : 'No source'}</span>
                          <span>{meta.label}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => startEdit(camera)} className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs font-bold text-slate-200 hover:bg-white/5"><Edit3 size={14}/> Edit</button>
                      <button onClick={() => remove(camera)} className="inline-flex items-center gap-2 rounded-lg border border-rose-400/15 px-3 py-2 text-xs font-bold text-rose-300 hover:bg-rose-400/10"><Trash2 size={14}/> Delete</button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-black text-white">{editing ? 'Edit Camera' : 'Add Camera'}</h2>
              <p className="mt-1 text-sm text-slate-500">Assign the camera to the correct parking operation point.</p>
            </div>
            {editing && <button onClick={resetForm} className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white"><X size={18}/></button>}
          </div>

          <form onSubmit={submit} className="space-y-4">
            <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Camera Name</span><input value={form.camera_name} onChange={e => updateField('camera_name', e.target.value)} placeholder="ENTRY-01" className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none focus:border-indigo-400/60" /></label>
            <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Location</span><input value={form.location} onChange={e => updateField('location', e.target.value)} placeholder="Main Entry Gate" className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none focus:border-indigo-400/60" /></label>

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Camera Role</span><select value={form.camera_role} onChange={e => updateField('camera_role', e.target.value as CameraRole)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none"><option value="ENTRY">Entry Gate</option><option value="EXIT">Exit Gate</option><option value="PARKING_ZONE">Parking Zone</option></select></label>
              <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Camera Type</span><select value={form.camera_type} onChange={e => updateField('camera_type', e.target.value as CameraType)} className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 text-white outline-none"><option value="USB">USB Camera</option><option value="IP">IP Camera</option><option value="RTSP">RTSP Stream</option><option value="UPLOAD">Upload Only</option><option value="DEMO">Demo Camera</option></select></label>
            </div>

            <label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-500">Stream source (optional)</span><input value={form.stream_url} onChange={e => updateField('stream_url', e.target.value)} placeholder={editing ? 'Enter a new source only to replace the saved source' : 'rtsp://camera-host:554/stream'} className="w-full rounded-xl border border-white/10 bg-slate-950/70 px-4 py-3 font-mono text-sm text-white outline-none focus:border-indigo-400/60" /><span className="mt-2 block text-xs text-slate-500">Saved sources are never returned by the API. Network camera hosts must be added to the server-side CAMERA_ALLOWED_HOSTS allowlist.</span></label>
            <p className="text-xs text-slate-500">Connection health is set by the server, not manually from this form.</p>

            <div className="rounded-xl border border-white/5 bg-white/[0.025] p-4 text-xs text-slate-500">
              <div className="flex items-center gap-2 font-bold text-slate-300"><CircleDot size={14} />{roleMeta[form.camera_role].label}</div>
              <p className="mt-2">{roleMeta[form.camera_role].description}. This role is used to organize the camera workflow inside the project.</p>
            </div>

            <div className="flex gap-3 pt-2">
              {editing && <button type="button" onClick={resetForm} className="flex-1 rounded-xl border border-white/10 px-4 py-3 font-bold text-slate-300 hover:bg-white/5">Cancel</button>}
              <button disabled={saving} type="submit" className="flex-1 inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-500 px-4 py-3 font-black text-white hover:bg-indigo-400 disabled:opacity-50"><Save size={17}/>{saving ? 'Saving…' : editing ? 'Update Camera' : 'Add Camera'}</button>
            </div>
          </form>
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {(['ENTRY','EXIT','PARKING_ZONE'] as CameraRole[]).map(role => {
          const meta = roleMeta[role];
          const camera = cameras.find(c => c.camera_role === role);
          return <div key={role} className="glass rounded-2xl p-5"><div className="flex items-center justify-between"><div className="text-xs font-bold uppercase tracking-widest text-slate-500">{meta.label}</div><span className="rounded-lg bg-white/5 px-2 py-1 text-[10px] font-black text-slate-400">{meta.icon}</span></div><div className="mt-3 text-lg font-black text-white">{camera?.camera_name || 'Not configured'}</div><div className="mt-1 text-xs text-slate-500">{camera?.location || 'Add a dedicated camera for this point.'}</div></div>;
        })}
      </div>
    </div>
  );
}
