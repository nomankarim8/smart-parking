"""Camera streaming utilities."""
 