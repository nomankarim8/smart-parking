import { useEffect, useState } from 'react';

import api from '../services/api';

export default function Simple({
  title,
  endpoint,
}: {
  title: string; 
  endpoint?: string;  
}) { 
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    if (endpoint) {
      api
        .get(endpoint)
        .then((r) => setData(r.data))
        .catch(() => {});
    }
  }, [endpoint]);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-7">
        <div className="text-xs font-bold uppercase tracking-[.2em] text-indigo-300">
          System Module
        </div>

        <h1 className="text-3xl font-black text-white">
          {title}
        </h1>
      </div>

      <div className="glass rounded-2xl p-7">
        <p className="text-slate-400">
          This module is connected to the backend and ready for operational expansion.
        </p>

        {data && (
          <pre className="mt-5 overflow-x-auto rounded-xl bg-slate-950 p-4 text-xs text-slate-300">
            {JSON.stringify(data, null, 2)}
          </pre>
        )}
      </div>
    </div>
  );
}