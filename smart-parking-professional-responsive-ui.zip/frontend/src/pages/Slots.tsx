import { useEffect, useState } from 'react';
import api from '../services/api';
import type { Slot } from '../types';
import SlotGrid from '../components/SlotGrid';

export default function Slots() {
  const [slots, setSlots] = useState<Slot[]>([]);

  useEffect(() => {
    api
      .get('/slots/')
      .then((r) => setSlots(r.data));
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      
      <div className="mb-7">
        
        <div className="text-xs font-bold uppercase tracking-[.2em] text-emerald-300">
          Parking Infrastructure
        </div>

        <h1 className="text-3xl font-black text-white">
          Parking Slots
        </h1>

      </div>

      <SlotGrid slots={slots} />

    </div>
  );
}