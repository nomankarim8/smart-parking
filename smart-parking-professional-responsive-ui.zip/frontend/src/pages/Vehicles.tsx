import { useEffect, useState } from 'react';
import api from '../services/api';
import type { Vehicle } from '../types';
import { Search, Plus } from 'lucide-react';

export default function Vehicles() {
  const [items, setItems] = useState<Vehicle[]>([]);
  const [q, setQ] = useState('');

  const load = () =>
    api
      .get('/vehicles/', {
        params: { q },
      })
      .then((r) => setItems(r.data));

  useEffect(() => {
    load();
  }, [q]);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="text-xs font-bold uppercase tracking-[.2em] text-cyan-300">
            Fleet Registry
          </div>

          <h1 className="text-3xl font-black text-white">
            Vehicles
          </h1>
        </div>

        <button className="flex items-center justify-center gap-2 rounded-xl bg-indigo-500 px-4 py-3 text-sm font-bold">
          <Plus size={17} />
          Add Vehicle
        </button>
      </div>

      <div className="glass overflow-hidden rounded-2xl">
        <div className="border-b border-slate-800 p-4">
          <div className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-950 px-3">
            <Search size={17} className="text-slate-500" />

            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search plate number..."
              className="w-full bg-transparent py-3 text-white outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-slate-950/70 text-xs uppercase tracking-widest text-slate-500">
              <tr>
                <th className="px-5 py-4">
                  Plate
                </th>

                <th>
                  Category
                </th>

                <th>
                  Owner
                </th>

                <th>
                  Model
                </th>

                <th>
                  Color
                </th>

                <th>
                  Created
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-800/70">
              {items.map((v) => (
                <tr
                  key={v.vehicle_id}
                  className="hover:bg-slate-900/40"
                >
                  <td className="px-5 py-4 font-black text-indigo-300">
                    {v.plate_number}
                  </td>

                  <td className="py-4 text-slate-300">
                    {v.category_id}
                  </td>

                  <td className="py-4 text-slate-400">
                    {v.owner_name || '—'}
                  </td>

                  <td className="py-4 text-slate-400">
                    {v.vehicle_model || '—'}
                  </td>

                  <td className="py-4 text-slate-400">
                    {v.vehicle_color || '—'}
                  </td>

                  <td className="py-4 text-slate-500">
                    {new Date(v.created_at).toLocaleDateString()}
                  </td>
                </tr>
              ))}

              {!items.length && (
                <tr>
                  <td
                    colSpan={6}
                    className="px-5 py-16 text-center text-slate-600"
                  >
                    No vehicles found
                  </td> 
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}