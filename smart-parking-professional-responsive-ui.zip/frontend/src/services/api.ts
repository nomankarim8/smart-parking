import axios from 'axios';
const api=axios.create({baseURL:import.meta.env.VITE_API_URL||'http://localhost:8000/api/v1'});
api.interceptors.request.use(c=>{const t=localStorage.getItem('smart_parking_token');if(t)c.headers.Authorization=`Bearer ${t}`;return c});
export default api;
